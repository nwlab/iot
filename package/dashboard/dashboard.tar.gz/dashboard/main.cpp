#include <QApplication>

#include "dashboard.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Dashboard w;
    w.show();
    return app.exec();
}
