"""
URIs templates for tiles
"""

ROOT_TILE_URL = 'http://tile.openweathermap.org/map/%s'
