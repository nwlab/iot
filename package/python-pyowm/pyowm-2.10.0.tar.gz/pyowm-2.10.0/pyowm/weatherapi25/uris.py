"""
URIs templates for resources exposed by the Weather API 2.5
"""

ICONS_BASE_URL = 'http://openweathermap.org/img/w/%s.png'
